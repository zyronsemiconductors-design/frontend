import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  Home, 
  Mail, 
  Users, 
  Settings, 
  LogOut, 
  Briefcase, 
  Users2, 
  MessageCircle,
  BookOpen
} from 'lucide-react';

const AdminLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const navItems = [
    { 
      id: 'dashboard', 
      label: 'Dashboard', 
      path: '/admin/dashboard', 
      icon: Home,
      visible: true
    },
    { 
      id: 'contacts', 
      label: 'Contact Inbox', 
      path: '/admin/contacts', 
      icon: Mail,
      visible: true
    },
    { 
      id: 'careers', 
      label: 'Job Applications', 
      path: '/admin/careers', 
      icon: Briefcase,
      visible: true
    },
    { 
      id: 'community', 
      label: 'Community Requests', 
      path: '/admin/community', 
      icon: Users2,
      visible: true
    },
    { 
      id: 'resources', 
      label: 'Resource Enquiries', 
      path: '/admin/resources', 
      icon: BookOpen,
      visible: true
    },
    { 
      id: 'users', 
      label: 'User Management', 
      path: '/admin/users', 
      icon: Users,
      visible: user?.role === 'super'
    },
    { 
      id: 'settings', 
      label: 'Settings', 
      path: '/admin/settings', 
      icon: Settings,
      visible: user?.role === 'super'
    }
  ];

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {/* Sidebar */}
      <div 
        className={`bg-gray-800 transition-all duration-300 ease-in-out flex flex-col ${
          sidebarOpen ? 'w-64' : 'w-16'
        }`}
      >
        <div className="p-4 border-b border-gray-700">
          <h1 className={`text-xl font-bold ${sidebarOpen ? 'block' : 'hidden'}`}>
            Admin Panel
          </h1>
        </div>
        
        <nav className="flex-1 p-2">
          <ul className="space-y-1">
            {navItems.filter(item => item.visible).map((item) => {
              const IconComponent = item.icon;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => navigate(item.path)}
                    className={`w-full flex items-center p-3 rounded-lg transition-colors ${
                      isActive(item.path)
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-300 hover:bg-gray-700'
                    }`}
                  >
                    <IconComponent size={20} />
                    <span className={`ml-3 ${sidebarOpen ? 'block' : 'hidden'}`}>
                      {item.label}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
        
        <div className="p-4 border-t border-gray-700">
          <button
            onClick={handleLogout}
            className="w-full flex items-center p-3 rounded-lg text-gray-300 hover:bg-gray-700 transition-colors"
          >
            <LogOut size={20} />
            <span className={`ml-3 ${sidebarOpen ? 'block' : 'hidden'}`}>
              Logout
            </span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-gray-800 border-b border-gray-700 p-4 flex justify-between items-center">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-gray-300 hover:text-white focus:outline-none"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d={sidebarOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
              />
            </svg>
          </button>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-300">
              Welcome, {user?.full_name || user?.email}
            </span>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-6 bg-gray-900">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;