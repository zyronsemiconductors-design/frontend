import React, { useState, useEffect } from 'react';
import { Users, Mail, Briefcase, MessageCircle, BookOpen, Activity, BarChart3 } from 'lucide-react';

interface StatItem {
  title: string;
  value: number;
  icon: React.ReactNode;
  color: string;
}

interface LogItem {
  id: string;
  type: string;
  title: string;
  time: string;
}

interface HealthStatus {
  database: string;
  auth: string;
  email: string;
}

interface DashboardData {
  stats: {
    contacts: number;
    careers: number;
    community: number;
    resources: number;
  };
  logs: LogItem[];
  health: HealthStatus;
}

const DashboardOverview: React.FC = () => {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'}/api/admin/stats`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('admin_token')}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch dashboard data');
      }

      const data = await response.json();
      setDashboardData(data);
    } catch (err: any) {
      setError(err.message || 'An error occurred while fetching dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const statItems: StatItem[] = dashboardData ? [
    {
      title: 'Contact Inquiries',
      value: dashboardData.stats.contacts,
      icon: <Mail className="h-8 w-8" />,
      color: 'text-blue-500'
    },
    {
      title: 'Job Applications',
      value: dashboardData.stats.careers,
      icon: <Briefcase className="h-8 w-8" />,
      color: 'text-green-500'
    },
    {
      title: 'Community Requests',
      value: dashboardData.stats.community,
      icon: <Users className="h-8 w-8" />,
      color: 'text-purple-500'
    },
    {
      title: 'Resource Enquiries',
      value: dashboardData.stats.resources,
      icon: <BookOpen className="h-8 w-8" />,
      color: 'text-yellow-500'
    }
  ] : [];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-900 text-red-100 p-4 rounded-md">
        Error: {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Dashboard Overview</h1>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <Activity className="h-4 w-4" />
          <span>Live</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statItems.map((stat, index) => (
          <div key={index} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{stat.title}</p>
                <p className="text-3xl font-bold text-white mt-2">{stat.value}</p>
              </div>
              <div className={stat.color}>
                {stat.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Health Status and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Health Status */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            System Health
          </h2>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Database</span>
              <span className={`px-2 py-1 rounded text-xs ${
                dashboardData?.health.database === 'NOMINAL' 
                  ? 'bg-green-900 text-green-300' 
                  : 'bg-red-900 text-red-300'
              }`}>
                {dashboardData?.health.database}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Authentication</span>
              <span className={`px-2 py-1 rounded text-xs ${
                dashboardData?.health.auth === 'STABLE' 
                  ? 'bg-green-900 text-green-300' 
                  : 'bg-red-900 text-red-300'
              }`}>
                {dashboardData?.health.auth}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Email Service</span>
              <span className={`px-2 py-1 rounded text-xs ${
                dashboardData?.health.email === 'STABLE' 
                  ? 'bg-green-900 text-green-300' 
                  : 'bg-red-900 text-red-300'
              }`}>
                {dashboardData?.health.email}
              </span>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
            <Activity className="h-5 w-5 mr-2" />
            Recent Activity
          </h2>
          <div className="space-y-4">
            {dashboardData?.logs && dashboardData.logs.length > 0 ? (
              dashboardData.logs.map((log) => (
                <div key={log.id} className="flex items-start">
                  <div className="flex-shrink-0">
                    {log.type === 'contact' && <Mail className="h-5 w-5 text-blue-500" />}
                    {log.type === 'career' && <Briefcase className="h-5 w-5 text-green-500" />}
                    {log.type === 'community' && <Users className="h-5 w-5 text-purple-500" />}
                    {log.type === 'resource' && <BookOpen className="h-5 w-5 text-yellow-500" />}
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-white">{log.title}</p>
                    <p className="text-xs text-gray-400">{new Date(log.time).toLocaleString()}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-400 text-center py-4">No recent activity</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;